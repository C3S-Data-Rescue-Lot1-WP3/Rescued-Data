
import pandas as pd
import os.path

from SEF_Pandas import rain


THIS_PATH = os.path.abspath(os.path.dirname(__file__))
OUTPUT_FOLDER = os.path.join(THIS_PATH, 'output')
OUTPUT_PATH = os.path.join(OUTPUT_FOLDER, 'SEF_rain_Maputo_Mozambique.tsv')


def import_excel(input_file_path):
    dfs = pd.read_excel(input_file_path, skiprows=1)
    dfs = dfs.fillna('')
    records = [dict(row[1]) for row in dfs.iterrows()]
    record = []
    for record_id in records:
        record.append(record_id)

    return records


def create_output_file():

    input_path = "/PATH/Rain.xls"
    records = import_excel(input_path)
    obs = rain.create(records)

    rain.write_file(obs, OUTPUT_PATH)


if __name__ == "__main__":
    create_output_file()
