SEF: A module for accessing Station Exchange Format files
=========================================================

.. automodule:: SEF
    :members:
    :imported-members:


