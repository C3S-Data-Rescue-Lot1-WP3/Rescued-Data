# SEF
Station Exchange Format library and specification
